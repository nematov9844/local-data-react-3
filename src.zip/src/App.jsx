import { useEffect, useState } from "react";
import "./App.css";
import data from "./assets/data/data";
import Header from "./leyaut/header/header";
function App() {
//  console.log(data);
 return <>
 <Header data={data.header}/>

  </>;
}

export default App;
