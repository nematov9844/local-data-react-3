import React from 'react'
import Style from './style.module.scss'
import Navbar from './navbar/navbar';
export default function Header({data}) {
  console.log(data);
  return (
    <div>
      <header className={Style.header}>
        <div><img src={data.logo} alt="" /></div>
<nav className={Style.nav}>
  <p>Anywhere</p>
  <p>Any week</p>
  <p>Add guests</p>
</nav>
<div className='action'> 
<p>Airbnb your home</p>
</div>
      </header>
      <div>
        <Navbar data={data.navbar} />
      </div>
    </div>
  )
}
