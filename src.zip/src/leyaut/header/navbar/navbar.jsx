import React from 'react'

export default function Navbar({data}) {
  console.log(data);
  return (
    <div>
      
    </div>
  )
}
